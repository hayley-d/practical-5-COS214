var searchData=
[
  ['removedevice_114',['removeDevice',['../classSmartHomeApplication.html#aa142531362a0d9d3e73a515d15045efc',1,'SmartHomeApplication']]],
  ['removeroom_115',['removeRoom',['../classSmartHomeApplication.html#ac1e04e70e9de0923bfa7bbd0e07c8b51',1,'SmartHomeApplication']]],
  ['removesensor_116',['removeSensor',['../classSmartRoom.html#a05c38804db6ec8f49fcc245d6210ef35',1,'SmartRoom']]],
  ['removesmartdevice_117',['removeSmartDevice',['../classSmartRoom.html#a55bc0177f8a3c37b83a962e464de95f5',1,'SmartRoom']]]
];
