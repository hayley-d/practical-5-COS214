var searchData=
[
  ['addcommand_90',['addCommand',['../classMacroCommand.html#a14aa6d4b32e0a3a5d1ac5bf53df85cb3',1,'MacroCommand']]],
  ['adddevice_91',['addDevice',['../classSmartHomeApplication.html#a7506ccae2f60b7e77855bc45ec5da2c2',1,'SmartHomeApplication']]],
  ['addroom_92',['addRoom',['../classSmartHomeApplication.html#a548cf4bc434fb0e3e69ec2d21bcf001f',1,'SmartHomeApplication']]],
  ['addsensor_93',['addSensor',['../classSmartRoom.html#a7bf5cc42b9c8e9d6c56147be714e614a',1,'SmartRoom']]],
  ['addsmartdevice_94',['addSmartDevice',['../classSmartRoom.html#a27b42a75f02851070e45253ee78cf72a',1,'SmartRoom::addSmartDevice(std::shared_ptr&lt; SmartLight &gt; device)'],['../classSmartRoom.html#abfde9c9fa0bdc926a7e7634d654580d1',1,'SmartRoom::addSmartDevice(std::shared_ptr&lt; SmartThermostat &gt; device)'],['../classSmartRoom.html#a5593d0bf2ad4a05c86c9a6541af5925e',1,'SmartRoom::addSmartDevice(std::shared_ptr&lt; SmartDoor &gt; device)']]]
];
