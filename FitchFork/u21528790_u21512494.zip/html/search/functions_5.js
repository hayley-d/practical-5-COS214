var searchData=
[
  ['increasetemperature_105',['increaseTemperature',['../classLegacyThermostat.html#ae61b8539421a633691f0b4b958781b5e',1,'LegacyThermostat']]],
  ['islocked_106',['isLocked',['../classSmartDoor.html#aad9aa02c5feb657e7a5b40fcedd75f30',1,'SmartDoor']]],
  ['ison_107',['isOn',['../classLegacyThermostat.html#a4e469ed6152d2411ca5f9d1b1a2650e9',1,'LegacyThermostat']]]
];
