var searchData=
[
  ['decreasetemperature_96',['decreaseTemperature',['../classLegacyThermostat.html#a5dabe7d7030c85c98333f118a4b045b0',1,'LegacyThermostat']]]
];
